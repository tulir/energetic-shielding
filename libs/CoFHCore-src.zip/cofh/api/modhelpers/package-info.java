/**
 * (C) 2014 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API(apiVersion = CoFHAPIProps.VERSION, owner = "CoFHAPI", provides = "CoFHAPI|modhelpers")
package cofh.api.modhelpers;

import cofh.api.CoFHAPIProps;
import cpw.mods.fml.common.API;

