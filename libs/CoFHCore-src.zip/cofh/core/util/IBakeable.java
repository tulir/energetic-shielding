package cofh.core.util;

public interface IBakeable {

	public void bake();
}
