package cofh.core.command;

import com.google.common.base.Throwables;

import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.init.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

public class CommandCountBlock implements ISubCommand {

	public static ISubCommand instance = new CommandCountBlock();

	@Override
	public String getCommandName() {

		return "countblocks";
	}

	@Override
	public int getPermissionLevel() {

		return 3;
	}

	@Override
	public void handleCommand(ICommandSender sender, String[] args) {

		if (args.length < 6) {
			sender.addChatMessage(new ChatComponentTranslation("info.cofh.command.syntaxError"));
			throw new WrongUsageException("info.cofh.command." + getCommandName() + ".syntax");
		}
		World world = sender.getEntityWorld();
		if (world.isRemote) {
			return;
		}

		ChunkCoordinates center = null;
		int i = 1;
		int xS, xL;
		if ("@".equals(args[i])) {
			center = sender.getPlayerCoordinates();
			++i;
			xS = CommandBase.parseInt(sender, args[i++]);
		} else {
			try {
				xS = CommandBase.parseInt(sender, args[i++]);
			} catch (Throwable t) {
				center = CommandBase.getPlayer(sender, args[i - 1]).getPlayerCoordinates();
				xS = CommandBase.parseInt(sender, args[i++]);
			}
		}
		int yS = CommandBase.parseInt(sender, args[i++]), yL;
		int zS = CommandBase.parseInt(sender, args[i++]), zL;
		int t = i + 1;

		try {
			xL = CommandBase.parseInt(sender, args[i++]);
			yL = CommandBase.parseInt(sender, args[i++]);
			zL = CommandBase.parseInt(sender, args[i++]);
		} catch (Throwable e) {
			if (i > t || center == null) {
				throw Throwables.propagate(e);
			}
			--i;
			xL = xS;
			yL = yS;
			zL = zS;
		}

		if (center != null) {
			xS = center.posX - xS;
			yS = center.posY - yS;
			zS = center.posZ - zS;

			xL = center.posX + xL;
			yL = center.posY + yL;
			zL = center.posZ + zL;
		}

		yS &= ~yS >> 31; // max(yS, 0)
		yL &= ~yL >> 31; // max(yL, 0)

		if (xL < xS) {
			t = xS;
			xS = xL;
			xL = t;
		}
		if (yL < yS) {
			t = yS;
			yS = yL;
			yL = t;
		}
		if (zL < zS) {
			t = zS;
			zS = zL;
			zL = t;
		}

		if (yS > 255) {
			sender.addChatMessage(new ChatComponentTranslation("info.cofh.command.syntaxError"));
			sender.addChatMessage(new ChatComponentTranslation("info.cofh.command." + getCommandName() + ".syntax"));
			return;
		} else if (yL > 255) {
			yL = 255;
		}

		long blockCounter = ((long) xL - xS) * ((long) yL - yS) * ((long) zL - zS);
		CommandHandler.logAdminCommand(sender, this, "info.cofh.command.countblocks.start", blockCounter, xS, yS, zS, xL, yL, zL);

		blockCounter = 0;
		for (int e = args.length; i < e; ++i) {
			String blockRaw = args[i];
			if (blockRaw.charAt(0) == '*') {
				if (blockRaw.equals("*fluid")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								if (block.getMaterial().isLiquid()) {
									++blockCounter;
								}
							}
						}
					}
				} else if (blockRaw.equals("*tree")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								if (block.isWood(world, x, y, z) || block.isLeaves(world, x, y, z)) {
									++blockCounter;
								}
							}
						}
					}
				} else if (blockRaw.startsWith("*repl")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								if (block.isReplaceable(world, x, y, z)) {
									++blockCounter;
								}
							}
						}
					}
				} else if (blockRaw.equals("*stone")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								if (block.isReplaceableOreGen(world, x, y, z, Blocks.stone) || block.isReplaceableOreGen(world, x, y, z, Blocks.netherrack)
										|| block.isReplaceableOreGen(world, x, y, z, Blocks.end_stone)) {
									++blockCounter;
								}
							}
						}
					}
				} else if (blockRaw.equals("*rock")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								if (block.getMaterial() == Material.rock) {
									++blockCounter;
								}
							}
						}
					}
				} else if (blockRaw.equals("*sand")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								if (block.getMaterial() == Material.sand) {
									++blockCounter;
								}
							}
						}
					}
				} else if (blockRaw.equals("*dirt")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								Material m = block.getMaterial();
								if (m == Material.grass || m == Material.ground || m == Material.clay || m == Material.snow || m == Material.craftedSnow
										|| m == Material.ice || m == Material.packedIce) {
									++blockCounter;
								}
							}
						}
					}
				} else if (blockRaw.startsWith("*plant")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								Material m = block.getMaterial();
								if (m == Material.plants || m == Material.vine || m == Material.cactus || m == Material.leaves) {
									++blockCounter;
								}
							}
						}
					}
				} else if (blockRaw.equals("*fire")) {
					for (int x = xS; x <= xL; ++x) {
						for (int z = zS; z <= zL; ++z) {
							Chunk chunk = world.getChunkFromBlockCoords(x, z);
							int cX = x & 15, cZ = z & 15;
							for (int y = yS; y <= yL; ++y) {
								Block block = chunk.getBlock(cX, y, cZ);
								Material m = block.getMaterial();
								if (m == Material.fire || m == Material.lava || block.isBurning(world, x, y, z)) {
									++blockCounter;
								}
							}
						}
					}
				}
				continue;
			}
			int meta = -1;
			t = blockRaw.indexOf('#');
			if (t > 0) {
				meta = CommandBase.parseInt(sender, blockRaw.substring(t + 1));
				blockRaw = blockRaw.substring(0, t);
			}
			Block block = Block.getBlockFromName(blockRaw);
			if (block == Blocks.air) {
				continue;
			}

			for (int x = xS; x <= xL; ++x) {
				for (int z = zS; z <= zL; ++z) {
					Chunk chunk = world.getChunkFromBlockCoords(x, z);
					int cX = x & 15, cZ = z & 15;
					for (int y = yS; y <= yL; ++y) {
						boolean v = meta == -1 || chunk.getBlockMetadata(cX, y, cZ) == meta;
						if (v && chunk.getBlock(cX, y, cZ) == block) {
							++blockCounter;
						}
					}
				}
			}
		}
		if (blockCounter != 0) {
			CommandHandler.logAdminCommand(sender, this, "info.cofh.command.countblocks.success", blockCounter, xS, yS, zS, xL, yL, zL);
		} else {
			CommandHandler.logAdminCommand(sender, this, "info.cofh.command.countblocks.failure");
		}
	}

	@Override
	public List<String> addTabCompletionOptions(ICommandSender sender, String[] args) {

		if (args.length == 2) {
			return CommandBase.getListOfStringsMatchingLastWord(args, MinecraftServer.getServer().getAllUsernames());
		}
		return null;
	}

}
