package cofh.thermalexpansion.block.simple;

import java.util.Random;

import net.minecraft.world.World;

public class BlockAirBarrier extends BlockAirBase {

	public BlockAirBarrier() {

		super(materialBarrier);
	}

	@Override
	public void randomDisplayTick(World world, int x, int y, int z, Random rand) {

	}

}
