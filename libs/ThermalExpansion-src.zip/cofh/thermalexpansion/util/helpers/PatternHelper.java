package cofh.thermalexpansion.util.helpers;

public class PatternHelper {

	private PatternHelper() {

	}

	// TODO: this should be a 2x2 or 3x3 or something of that nature
}
